import SwiftUI
import UIKit

struct ContentView: View {
    @AppStorage("aimHeadEnabled") private var aimHead = false
    @AppStorage("aimBodyEnabled") private var aimBody = false
    @AppStorage("aimLockEnabled") private var aimLock = false
    @AppStorage("generalSensitivity") private var general = 180.0
    @AppStorage("redDotSensitivity") private var redDot = 175.0
    @AppStorage("scope2xSensitivity") private var scope2x = 165.0
    @AppStorage("scope4xSensitivity") private var scope4x = 150.0

    private let pink = Color(red: 1, green: 0.20, blue: 0.78)
    private let purple = Color(red: 0.58, green: 0.25, blue: 1)

    var body: some View {
        ZStack {
            background
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("HINDUSTANHACK")
                            .font(.system(size: 10, weight: .black, design: .rounded))
                            .tracking(2.5).foregroundStyle(pink)
                        Text("FF AIM PRO")
                            .font(.system(size: 35, weight: .black, design: .rounded))
                            .foregroundStyle(.white)
                            .shadow(color: pink.opacity(0.8), radius: 14)
                        Text("NEON ANIME EDITION")
                            .font(.system(size: 10, weight: .bold, design: .monospaced))
                            .tracking(1.4).foregroundStyle(.white.opacity(0.8))
                    }.padding(.top, 14)

                    panel("AIM CONTROL", caption: "APP-SIDE SETTINGS ONLY") {
                        ToggleRow(title: "AIM HEAD", detail: "Head-aim profile", isOn: $aimHead, pink: pink)
                        Divider().overlay(.white.opacity(0.12))
                        ToggleRow(title: "AIM BODY", detail: "Body-aim profile", isOn: $aimBody, pink: pink)
                        Divider().overlay(.white.opacity(0.12))
                        ToggleRow(title: "AIM LOCK", detail: "Configuration toggle only", isOn: $aimLock, pink: pink)
                    }

                    panel("SENSITIVITY", caption: "ADJUST AND SAVE LOCALLY") {
                        SensitivityRow(title: "GENERAL", value: $general, pink: pink)
                        SensitivityRow(title: "RED DOT", value: $redDot, pink: pink)
                        SensitivityRow(title: "SCOPE 2X", value: $scope2x, pink: pink)
                        SensitivityRow(title: "SCOPE 4X", value: $scope4x, pink: pink)
                    }

                    ShareLink(item: exportedConfig) {
                        Label("EXPORT CONFIGURATION", systemImage: "square.and.arrow.up")
                            .font(.system(size: 13, weight: .black, design: .rounded))
                            .tracking(1).frame(maxWidth: .infinity).padding(.vertical, 15)
                            .background(LinearGradient(colors: [pink, purple], startPoint: .leading, endPoint: .trailing))
                            .foregroundStyle(.white).clipShape(RoundedRectangle(cornerRadius: 13))
                    }

                    Text("Standalone settings app. Does not modify or control Free Fire.")
                        .font(.footnote).foregroundStyle(.white.opacity(0.75))
                        .frame(maxWidth: .infinity).multilineTextAlignment(.center)
                        .padding(.bottom, 20)
                }.padding(.horizontal, 16)
            }
        }.preferredColorScheme(.dark)
    }

    @ViewBuilder private var background: some View {
        GeometryReader { geo in
            ZStack {
                Color.black
                #if canImport(UIKit)
                if UIImage(named: "AnimeBackground") != nil {
                    Image("AnimeBackground").resizable().scaledToFill()
                        .frame(width: geo.size.width, height: geo.size.height).clipped()
                } else {
                    LinearGradient(colors: [purple.opacity(0.45), .black, pink.opacity(0.18)],
                                   startPoint: .topLeading, endPoint: .bottomTrailing)
                }
                #endif
                Color.black.opacity(0.57)
                LinearGradient(colors: [.clear, .black.opacity(0.8)],
                               startPoint: .top, endPoint: .bottom)
            }.ignoresSafeArea()
        }
    }

    private func panel<Content: View>(_ title: String, caption: String,
                                      @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 13) {
            VStack(alignment: .leading, spacing: 4) {
                Text(title).font(.system(size: 13, weight: .black, design: .rounded))
                    .tracking(1.5).foregroundStyle(.white)
                Text(caption).font(.system(size: 9, weight: .medium, design: .monospaced))
                    .tracking(0.8).foregroundStyle(pink)
            }
            content()
        }
        .padding(15)
        .background(.ultraThinMaterial)
        .background(Color.black.opacity(0.42))
        .overlay(RoundedRectangle(cornerRadius: 18).stroke(pink.opacity(0.48), lineWidth: 0.8))
        .clipShape(RoundedRectangle(cornerRadius: 18))
    }

    private var exportedConfig: String {
        """
        FF AIM PRO CONFIG
        Aim Head: \(aimHead ? "ON" : "OFF")
        Aim Body: \(aimBody ? "ON" : "OFF")
        Aim Lock: \(aimLock ? "ON" : "OFF")
        General: \(Int(general))
        Red Dot: \(Int(redDot))
        Scope 2x: \(Int(scope2x))
        Scope 4x: \(Int(scope4x))
        """
    }
}

private struct ToggleRow: View {
    let title: String
    let detail: String
    @Binding var isOn: Bool
    let pink: Color
    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: "scope").foregroundStyle(pink)
                .frame(width: 36, height: 36).background(pink.opacity(0.14))
                .clipShape(RoundedRectangle(cornerRadius: 10))
            VStack(alignment: .leading, spacing: 3) {
                Text(title).font(.system(size: 12, weight: .black, design: .rounded))
                    .tracking(0.8).foregroundStyle(.white)
                Text(detail).font(.system(size: 10)).foregroundStyle(.white.opacity(0.65))
            }
            Spacer()
            Toggle(title, isOn: $isOn).labelsHidden().tint(pink)
        }.padding(.vertical, 3)
    }
}

private struct SensitivityRow: View {
    let title: String
    @Binding var value: Double
    let pink: Color
    var body: some View {
        VStack(spacing: 6) {
            HStack {
                Text(title).font(.system(size: 11, weight: .bold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.88))
                Spacer()
                Text("\(Int(value))").font(.system(size: 12, weight: .black, design: .monospaced))
                    .foregroundStyle(pink)
            }
            Slider(value: $value, in: 0...200, step: 1).tint(pink)
        }
    }
}
