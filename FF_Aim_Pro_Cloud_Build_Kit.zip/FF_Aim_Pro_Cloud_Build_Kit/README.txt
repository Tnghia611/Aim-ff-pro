FF AIM PRO — CLOUD BUILD KIT (iPhone-friendly handoff)

What is included:
- FFAimPro/FFAimProApp.swift
- FFAimPro/ContentView.swift
- FFAimPro/Assets.xcassets/ (anime background asset if available)
- GitHub Actions workflow for cloud macOS build

Important:
This source does not contain a signed IPA. Cloud build services require a repository and may require signing credentials or an Apple developer team. Never upload private certificates or passwords to an untrusted service. The app's Aim Head / Aim Body / Aim Lock switches only save app-side settings; they do not automate aiming or alter Free Fire.

iPhone workflow:
1. Download and unzip this kit in Files.
2. Upload the extracted project files to a private GitHub repository (GitHub website can be used in Safari; uploading folders may be easier through GitHub's web UI or a trusted Git client).
3. Open the repository's Actions tab. The workflow included here can compile the Swift files as an iOS Simulator build artifact, but a simulator app is not installable on a physical iPhone.
4. For a device-installable IPA, use a trusted cloud build/signing service that explicitly supports iOS device archives and IPA export, then download its IPA artifact.
5. Import the IPA into ESign and sign/install with your working certificate, subject to the certificate's entitlements and trust status.

A true device IPA cannot be guaranteed from this source-only ZIP without a real iOS build/signing service and valid provisioning.
